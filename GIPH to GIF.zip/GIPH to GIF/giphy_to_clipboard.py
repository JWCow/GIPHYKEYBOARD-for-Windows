import requests
import io
import tkinter as tk
from tkinter import ttk, messagebox
from PIL import Image
import win32clipboard
from io import BytesIO
import os
import tempfile
import struct
from PIL import ImageSequence

class GiphyClipboard:
    def __init__(self, root):
        self.root = root
        self.root.title("GIPHY to Clipboard")
        self.root.geometry("400x120")
        
        # Create main frame with padding
        self.main_frame = ttk.Frame(root, padding="20")
        self.main_frame.grid(row=0, column=0, sticky="nsew")
        
        # URL label
        self.url_label = ttk.Label(self.main_frame, text="Paste GIPHY URL:")
        self.url_label.grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 5))
        
        # URL entry
        self.url_var = tk.StringVar()
        self.url_entry = ttk.Entry(self.main_frame, textvariable=self.url_var, width=50)
        self.url_entry.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(0, 10))
        self.url_entry.bind('<Return>', lambda e: self.copy_to_clipboard())
        
        # Copy button
        self.copy_button = ttk.Button(
            self.main_frame, 
            text="Copy to Clipboard", 
            command=self.copy_to_clipboard
        )
        self.copy_button.grid(row=2, column=0, columnspan=2)
        
        # Status label
        self.status_var = tk.StringVar()
        self.status_label = ttk.Label(
            self.main_frame, 
            textvariable=self.status_var,
            foreground="gray"
        )
        self.status_label.grid(row=3, column=0, columnspan=2, pady=(5, 0))
        
        # Configure grid weights
        root.columnconfigure(0, weight=1)
        root.rowconfigure(0, weight=1)
        self.main_frame.columnconfigure(1, weight=1)
        
        # Set focus to URL entry
        self.url_entry.focus()
        
        # Create temp directory for GIFs
        self.temp_dir = tempfile.mkdtemp()
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)

    def compress_gif(self, image_data, max_size_kb=1024):
        """Compress GIF to be under max_size_kb"""
        img = Image.open(BytesIO(image_data))
        
        # If already under max size, return original
        if len(image_data) <= max_size_kb * 1024:
            return image_data

        # Calculate new size while maintaining aspect ratio
        scale_factor = 0.9  # Start with 90% of original size
        while True:
            # Create new GIF with reduced size
            frames = []
            width = int(img.width * scale_factor)
            height = int(img.height * scale_factor)
            
            for frame in ImageSequence.Iterator(img):
                resized_frame = frame.copy()
                resized_frame.thumbnail((width, height), Image.Resampling.LANCZOS)
                frames.append(resized_frame)
            
            # Save compressed GIF to memory
            output = BytesIO()
            frames[0].save(
                output,
                save_all=True,
                append_images=frames[1:],
                format='GIF',
                optimize=True,
                quality=70
            )
            compressed_data = output.getvalue()
            
            # Check if size is under limit
            if len(compressed_data) <= max_size_kb * 1024:
                return compressed_data
            
            # Reduce size further
            scale_factor *= 0.9
            if scale_factor < 0.1:  # Prevent infinite loop
                raise Exception("Could not compress GIF under 500KB while maintaining quality")
    
    def on_closing(self):
        """Clean up temporary files when closing the application"""
        try:
            for file in os.listdir(self.temp_dir):
                os.remove(os.path.join(self.temp_dir, file))
            os.rmdir(self.temp_dir)
        except:
            pass
        self.root.destroy()
    
    def copy_to_clipboard(self):
        url = self.url_var.get().strip()
        if not url:
            self.status_var.set("Please enter a GIPHY URL")
            return
        
        try:
            # Download the GIF
            response = requests.get(url)
            response.raise_for_status()

            # Compress GIF if needed
            gif_data = self.compress_gif(response.content)

            # Save compressed GIF to temporary file
            temp_gif_path = os.path.join(self.temp_dir, "temp.gif")
            with open(temp_gif_path, 'wb') as f:
                f.write(gif_data)

            # Show file size
            file_size_kb = os.path.getsize(temp_gif_path) / 1024
            self.status_var.set(f"GIF size: {file_size_kb:.1f}KB")

            # Prepare the file list for clipboard
            files = [temp_gif_path]
            file_list = '\0'.join(files) + '\0\0'
            
            # Calculate size needed for DROPFILES structure
            offset = struct.calcsize('20s') # DROPFILES structure size
            size = offset + len(file_list.encode('utf-16le'))
            
            # Create DROPFILES structure
            fmt = 'llllI{}s'.format(len(file_list) * 2)
            dropfiles = struct.pack(fmt,
                20, # offset where file list begins
                0,  # screen coordinates of drag point
                0,  # screen coordinates of drag point
                0,  # not used
                1,  # contains wide-character file names
                file_list.encode('utf-16le'))  # file list

            # Copy to clipboard
            win32clipboard.OpenClipboard()
            win32clipboard.EmptyClipboard()
            win32clipboard.SetClipboardData(win32clipboard.CF_HDROP, dropfiles)
            win32clipboard.CloseClipboard()

            self.status_var.set(f"GIF copied! Size: {file_size_kb:.1f}KB")
            self.url_var.set("")  # Clear the URL field
            
        except Exception as e:
            self.status_var.set(f"Error: {str(e)}")
            if win32clipboard.IsClipboardFormatAvailable(win32clipboard.CF_HDROP):
                win32clipboard.CloseClipboard()

if __name__ == "__main__":
    root = tk.Tk()
    app = GiphyClipboard(root)
    root.mainloop() 